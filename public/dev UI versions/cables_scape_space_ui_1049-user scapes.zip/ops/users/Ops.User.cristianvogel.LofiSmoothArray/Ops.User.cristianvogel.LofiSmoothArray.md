Use this op to smoothly interpolate between differences in the values of an array.
It has two modes which can be selected with the `separate inc/dec` option.

One mode applies the same smooth factor to values which increase or decrease.
The other mode allows separate control over the smooth factor for increasing or decreasing values.
