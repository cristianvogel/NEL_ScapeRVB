// inputs
const parentPort = op.inObject("link");
const buttonTextPort = op.inString("Text", "Button");
const checksum = op.inValue("Checksum", 0);
const update = op.inTrigger("update");

const inGreyOut = op.inBool("Grey Out", false);
const inVisible = op.inBool("Visible", true);

// outputs
const siblingsPort = op.outObject("childs");
const buttonPressedPort = op.outTrigger("Pressed Trigger");


// vars
const colors = ["rgba(85,85,85,0.5)", "aquamarine"];

const el = document.createElement("div");
el.dataset.op = op.id;
el.classList.add("cablesEle");
el.classList.add("sidebar__item");
el.classList.add("sidebar--button");
el.style.display = "grid";
el.style.gridTemplateColumns = "0.25fr 1fr";
el.style.alignItems = "start";
el.style.alignContent = "stretch";
el.style.height = "75px";
el.style.paddingLeft = "5px";


// draw svg
const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
svg.setAttribute("viewBox", "0 0 100 100");
svg.setAttribute("width", "100%");
svg.setAttribute("height", "150%");
svg.style.gridColumn = "1 / 2";



const quadrants = [];


for (let i = 0; i < 4; i++) {
    const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    rect.setAttribute("x", [ "0", "25", "50", "75" ][i]);
    rect.setAttribute("y", "0");

    rect.setAttribute("width", "20");
    rect.setAttribute("height", "20");
    rect.setAttribute("fill", colors[0]);
    rect.setAttribute("rx", "50"); // Round the corners with a radius of 10
    rect.setAttribute("ry", "50"); // Round the corners with a radius of 10
    rect.style.display = "block";
    quadrants.push(rect);
    svg.appendChild(rect);
}

svg.setAttribute("transform", "translate(-2.5, -17)")


function showQuadrant( index ) {
    if (index < 0 || index > quadrants.length) return;
    quadrants.forEach((quad, i) => {
        quad.style.fill = i <= index - 1 || index === 4 ? colors[1] : colors[0];
    });
}


updateSegments();

function updateSegments () {

el.appendChild( svg );
showQuadrant( Math.round( checksum.get() ) )

 }

 checksum.onChange = updateSegments;


update.onTriggered = updateSegments;

const button = document.createElement("div");
button.classList.add("sidebar__button-input");
button.style.gridColumn = "2 / 3";
el.appendChild(button);

const inputText = document.createTextNode(buttonTextPort.get());
button.appendChild(inputText);


button.addEventListener("click", onButtonClick);

op.toWorkNeedsParent("Ops.Sidebar.Sidebar");

// events
parentPort.onChange = onParentChanged;
buttonTextPort.onChange = onButtonTextChanged;
op.onDelete = onDelete;


const greyOut = document.createElement("div");
greyOut.classList.add("sidebar__greyout");
greyOut.style.gridColumn = "1 / 4";
el.appendChild(greyOut);
greyOut.style.display = "none";

inGreyOut.onChange = function ()
{
    greyOut.style.display = inGreyOut.get() ? "block" : "none";
};

inVisible.onChange = function ()
{
    el.style.display = inVisible.get() ? "grid" : "none";
};

function onButtonClick()
{
    buttonPressedPort.trigger();
}

function onButtonTextChanged()
{
    const buttonText = buttonTextPort.get();
    button.textContent = buttonText;
    if (CABLES.UI)
    {
        op.setUiAttrib({ "extendTitle": buttonText });
    }
}

function onParentChanged()
{
    siblingsPort.set(null);
    const parent = parentPort.get();
    if (parent && parent.parentElement)
    {
        parent.parentElement.appendChild(el);
        siblingsPort.set(parent);
    }
    else
    { // detach
        if (el.parentElement)
        {
            el.parentElement.removeChild(el);
        }
    }
}

function showElement(el)
{
    if (el)
    {
        el.style.display = "grid";
    }
}

function hideElement(el)
{
    if (el)
    {
        el.style.display = "none";
    }
}

function onDelete()
{
    removeElementFromDOM(el);
}

function removeElementFromDOM(el)
{
    if (el && el.parentNode && el.parentNode.removeChild)
    {
        el.parentNode.removeChild(el);
    }
}


