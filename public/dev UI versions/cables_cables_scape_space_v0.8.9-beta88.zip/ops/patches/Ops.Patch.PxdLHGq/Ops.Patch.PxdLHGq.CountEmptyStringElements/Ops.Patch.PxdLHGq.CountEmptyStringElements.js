const
    exec = op.inTrigger("Trigger"),
    arr = op.inArray("Array"),
    result = op.outNumber("Result");

let count = 0;

exec.onTriggered = () => {
    if (!arr.get()) return;

    count = 0; // Reset count each time the trigger is executed

    for (let str of arr.get()) {
        if (str.includes( "SURFACE" ) || str.includes("LIGHT") || str.includes("TEMPLE") || str.includes("DEEPNESS")) continue;
        if (str.length > 0) count++
    }

    result.set(count);
};