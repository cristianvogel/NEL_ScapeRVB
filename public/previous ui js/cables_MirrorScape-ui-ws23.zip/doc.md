## Patch Variables:

* ____bodyHitY__ ```Number```
* ____currentReflectorParam__ ```String```
* ____heightMapGeometry__ ```Object```
* ____labelBoolAnim__ ```Number```
* ____lensFlareTexts__ ```Texture```
* ___currentDialValueInsideRepeat2D__ ```Number```
* ___currentIndexInsideRepeat2D__ ```Number```
* ___currentInstanceIsActive__ ```Number```
* ___finalTextOut__ ```Texture```
* ___rep2d_x__ ```Number```
* __ext_additionalParams_object__ ```Object```
* __ext_changingParamID__ ```String``` (default Value: `New String`)
* __ext_normValue__ ```Number``` (default Value: `0`)
* __ext_srvbParams_object__ ```Object```
* __NEL_SRVB_Metals__ ```Object```
* __ringG__ ```Number```
* __ringR__ ```Number```
* __ui_activeDial_ID__ ```Number```
* __ui_additionalParams_object__ ```Object```
* __ui_dialValues_array__ ```Array```
* __ui_hitBodyName__ ```String```
* __ui_leftButtonIsDown__ ```Number```
* __ui_mouseIsChangingDialValue__ ```Number```

  detect interaction with the GL dials

* __ui_mouseIsChangingParamID__ ```String``` (default Value: `New String`)
* __ui_mouseOverParamID__ ```String```
* __ui_normValue__ ```Number```
* __ui_smoothedParam_diffusion__ ```Number```
* __ui_smoothedParam_mix__ ```Number```
* __ui_smoothedParam_size__ ```Number```
* __ui_smoothedParam_tone__ ```Number```

